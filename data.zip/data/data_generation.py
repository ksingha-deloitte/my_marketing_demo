import os
import random
from pathlib import Path

import numpy as np
import pandas as pd


def generate_marketing_data(num_rows: int = 500, output_excel: bool = True, excel_path: str = "data/marketing_data.xlsx") -> pd.DataFrame:
    """Generate a realistic marketing campaign dataset and export it to Excel."""
    random.seed(42)
    np.random.seed(42)

    platforms = ["Meta", "Google", "LinkedIn"]
    audience_segments = [
        "Tech Bros 25-34",
        "Soccer Moms",
        "Budget Travelers",
        "Enterprise Decision Makers",
        "Fitness Enthusiasts",
        "Eco-Conscious Shoppers",
        "Luxury Seekers",
        "Foodies",
        "Startup Founders",
        "Young Professionals 18-24",
    ]
    creative_names = [
        "Launch Promo",
        "Limited Offer",
        "Social Proof Ad",
        "Video Carousel",
        "Value Message",
        "Urgency Push",
        "Brand Story",
        "Holiday Special",
        "Customer Testimonial",
        "Product Demo",
    ]

    bad_segments = {"Soccer Moms", "Budget Travelers", "Tech Bros 25-34"}

    data = []
    for row_id in range(1, num_rows + 1):
        platform = random.choice(platforms)
        segment = random.choice(audience_segments)
        creative = random.choice(creative_names)
        campaign_id = f"CMP-{row_id:04d}"

        if segment in bad_segments:
            spend = round(np.random.uniform(2000, 7000), 2)
            impressions = int(np.random.uniform(25000, 90000))
            clicks = int(np.random.uniform(100, 600))
            conversions = int(np.random.choice([0, 1, 2, 3, 4], p=[0.3, 0.25, 0.2, 0.15, 0.1]))
        else:
            spend = round(np.random.uniform(800, 4200), 2)
            impressions = int(np.random.uniform(25000, 120000))
            clicks = int(np.random.uniform(700, 4200))
            conversions = int(np.random.choice([3, 4, 5, 6, 7, 8, 9, 10], p=[0.05, 0.1, 0.15, 0.2, 0.2, 0.15, 0.1, 0.05]))

        ctr = clicks / impressions if impressions else 0
        revenue = conversions * np.random.uniform(80, 350)
        cpa = spend / conversions if conversions else spend * 2
        roas = revenue / spend if spend else 0

        data.append(
            {
                "Campaign ID": campaign_id,
                "Platform": platform,
                "Audience Segment": segment,
                "Ad Creative Name": creative,
                "Spend ($)": spend,
                "Impressions": impressions,
                "Clicks": clicks,
                "Conversions": conversions,
                "CTR": round(ctr * 100, 2),
                "CPA ($)": round(cpa, 2),
                "ROAS": round(roas, 2),
            }
        )

    df = pd.DataFrame(data)
    df.sort_values(by=["Platform", "Audience Segment", "Campaign ID"], inplace=True)
    df.reset_index(drop=True, inplace=True)

    if output_excel:
        output_path = Path(excel_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_excel(output_path, index=False)

    return df


if __name__ == "__main__":
    generate_marketing_data()
